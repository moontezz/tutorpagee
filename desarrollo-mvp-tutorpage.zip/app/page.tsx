'use client'

import { useEffect, useMemo, useState } from 'react'
import {
  CalendarDays,
  CheckCircle2,
  ChevronRight,
  Clock3,
  GraduationCap,
  LayoutDashboard,
  LogOut,
  Menu,
  Search,
  Settings,
  Star,
  UserCircle2,
  Users,
  X,
  BookOpen,
  ShieldCheck,
} from 'lucide-react'

type Tutor = { id: number; name: string; subject: string; career: string; expertise: string; rating: number; sessions: number; color: string; initials: string; availability: string }
type Booking = { id: number; tutor: string; subject: string; date: string; time: string; mode: string; status: 'Confirmada' | 'Cancelada' }
type Account = { name: string; email: string; career: string; university: string; createdAt: string }

const emptyAccount = (name: string, email: string): Account => ({ name, email, career: 'Estudiante', university: 'Universidad Nacional', createdAt: new Date().getFullYear().toString() })
const accountKey = (email: string) => `tutorpage-account-${email.trim().toLowerCase()}`
const initials = (name: string) => name.split(' ').filter(Boolean).slice(0, 2).map(part => part[0]).join('').toUpperCase()

const tutors: Tutor[] = [
  ['Mariana Torres','Cálculo','Ingeniería Matemática','Cálculo diferencial y álgebra lineal',4.9,128,'#dbeafe','MT','Hoy, 16:00'],
  ['Diego Ramírez','Programación','Ingeniería de Sistemas','Python, JavaScript y estructuras de datos',4.8,96,'#dcfce7','DR','Mañana, 10:00'],
  ['Sofía Mendoza','Inglés','Lenguas Modernas','Conversación, TOEFL y gramática',5.0,74,'#fef3c7','SM','Hoy, 18:30'],
  ['Andrés Castillo','Física','Física Aplicada','Mecánica, electricidad y termodinámica',4.9,115,'#fce7f3','AC','Jue, 14:00'],
  ['Valentina Rojas','Química','Química','Química orgánica y laboratorio',4.7,63,'#ede9fe','VR','Vie, 09:00'],
  ['Mateo Gómez','Estadística','Economía','Probabilidad, R y análisis de datos',4.8,88,'#cffafe','MG','Hoy, 17:00'],
  ['Laura Silva','Biología','Biología','Genética, microbiología y ciencias naturales',4.9,52,'#d1fae5','LS','Mañana, 15:30'],
  ['Santiago Pérez','Cálculo','Ingeniería Civil','Cálculo integral y ecuaciones diferenciales',4.6,47,'#ffedd5','SP','Jue, 11:00'],
  ['Camila Vargas','Diseño','Diseño Gráfico','Figma, UX/UI y diseño editorial',4.9,39,'#f3e8ff','CV','Hoy, 19:00'],
  ['Nicolás León','Economía','Economía','Microeconomía y finanzas',4.8,61,'#e0f2fe','NL','Vie, 13:00'],
  ['Paula Herrera','Historia','Historia','Historia contemporánea y ensayo',4.9,34,'#fef9c3','PH','Mañana, 11:30'],
  ['Tomás Ruiz','Filosofía','Humanidades','Lógica, ética y pensamiento crítico',4.7,29,'#e2e8f0','TR','Jue, 16:30'],
  ['Isabella Cruz','Contabilidad','Contaduría Pública','Contabilidad financiera y costos',4.8,45,'#fee2e2','IC','Vie, 16:00'],
  ['Gabriel Mora','Álgebra','Matemáticas','Álgebra abstracta y geometría',4.9,57,'#dbeafe','GM','Hoy, 15:00'],
  ['Natalia Díaz','Redacción','Comunicación','Escritura académica y ortografía',5.0,41,'#fce7f3','ND','Mañana, 17:30'],
  ['Juan Esteban','Marketing','Administración','Marketing digital y estrategia',4.8,36,'#ffedd5','JE','Vie, 10:30'],
  ['Renata Ocampo','Francés','Lenguas Modernas','Francés conversacional y DELF',4.9,27,'#ede9fe','RO','Jue, 18:00'],
  ['Felipe Arias','Bases de Datos','Ingeniería de Sistemas','SQL, modelado y SQLite',4.9,82,'#dcfce7','FA','Hoy, 20:00'],
  ['Ana Lucía','Anatomía','Medicina','Anatomía humana y fisiología',4.8,68,'#fee2e2','AL','Mañana, 08:00'],
  ['Sebastián Vega','Cálculo','Ingeniería Electrónica','Cálculo vectorial y señales',4.7,49,'#cffafe','SV','Vie, 15:00'],
].map((t, i) => ({ id: i + 1, name: t[0] as string, subject: t[1] as string, career: t[2] as string, expertise: t[3] as string, rating: t[4] as number, sessions: t[5] as number, color: t[6] as string, initials: t[7] as string, availability: t[8] as string }))

const extraTutors: Tutor[] = Array.from({ length: 30 }, (_, index) => {
  const subjects = ['Cálculo', 'Programación', 'Inglés', 'Física', 'Química', 'Estadística', 'Biología', 'Diseño', 'Economía', 'Redacción']
  const careers = ['Ingeniería de Sistemas', 'Ingeniería Civil', 'Matemáticas', 'Administración', 'Ciencias Sociales']
  const names = ['Alejandra', 'Bruno', 'Carolina', 'Daniel', 'Elena', 'Fernando', 'Gabriela', 'Hugo', 'Irene', 'Julián']
  const subject = subjects[index % subjects.length]
  const name = `${names[index % names.length]} ${['López', 'Martínez', 'García', 'Sánchez', 'Pineda'][index % 5]}`
  return { id: index + 21, name, subject, career: careers[index % careers.length], expertise: `${subject}, preparación de exámenes y resolución de problemas`, rating: Number((4.6 + (index % 5) / 10).toFixed(1)), sessions: 20 + index * 3, color: ['#dbeafe', '#dcfce7', '#fef3c7', '#fce7f3', '#ede9fe'][index % 5], initials: name.split(' ').map(part => part[0]).join(''), availability: `${['Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes'][index % 5]} · ${String(8 + (index % 10)).padStart(2, '0')}:00 - ${String(9 + (index % 10)).padStart(2, '0')}:00` }
})
tutors.push(...extraTutors)

const initialBookings: Booking[] = [
  { id: 101, tutor: 'Mariana Torres', subject: 'Cálculo', date: 'Miércoles, 09 de octubre', time: '16:00 - 17:00', mode: 'Videollamada', status: 'Confirmada' },
  { id: 102, tutor: 'Diego Ramírez', subject: 'Programación', date: 'Viernes, 11 de octubre', time: '10:00 - 11:00', mode: 'Videollamada', status: 'Confirmada' },
]

export default function Page() {
  const [signedIn, setSignedIn] = useState(false)
  const [authMode, setAuthMode] = useState<'login' | 'register'>('login')
  const [active, setActive] = useState('Inicio')
  const [query, setQuery] = useState('')
  const [subject, setSubject] = useState('Todas')
  const [selected, setSelected] = useState<Tutor | null>(null)
  const [bookings, setBookings] = useState<Booking[]>([])
  const [favorites, setFavorites] = useState<number[]>([])
  const [account, setAccount] = useState<Account>(emptyAccount('', ''))
  const [toast, setToast] = useState('')
  const [mobileMenu, setMobileMenu] = useState(false)


  useEffect(() => {
    try {
      const sessionEmail = window.localStorage.getItem('tutorpage-session')
      if (!sessionEmail) return
      const saved = window.localStorage.getItem(accountKey(sessionEmail))
      if (!saved) return
      const data = JSON.parse(saved)
      setAccount(data.account); setBookings(data.bookings ?? []); setFavorites(data.favorites ?? []); setSignedIn(true)
    } catch { /* comienza con una cuenta limpia */ }
  }, [])
  const persist = (nextBookings: Booking[] = bookings, nextFavorites: number[] = favorites, nextAccount: Account = account) => window.localStorage.setItem(accountKey(nextAccount.email), JSON.stringify({ account: nextAccount, bookings: nextBookings, favorites: nextFavorites }))
  const signIn = (name: string, email: string, isNew: boolean) => {
    const normalizedEmail = email.trim().toLowerCase()
    const key = accountKey(normalizedEmail)
    const saved = window.localStorage.getItem(key)
    const data = saved ? JSON.parse(saved) : { account: emptyAccount(name.trim() || 'Estudiante', normalizedEmail), bookings: [], favorites: [] }
    if (isNew && !saved) window.localStorage.setItem(key, JSON.stringify(data))
    setAccount(data.account); setBookings(data.bookings ?? []); setFavorites(data.favorites ?? []); window.localStorage.setItem('tutorpage-session', normalizedEmail); setSignedIn(true); showToast('Bienvenido a tutorpage')
  }
  const filtered = useMemo(() => tutors.filter(t => (subject === 'Todas' || t.subject === subject) && `${t.name} ${t.subject} ${t.career} ${t.expertise}`.toLowerCase().includes(query.toLowerCase())), [query, subject])
  const showToast = (message: string) => { setToast(message); window.setTimeout(() => setToast(''), 2800) }
  const bookTutor = (tutor: Tutor, date = tutor.availability) => { const next = [{ id: Date.now(), tutor: tutor.name, subject: tutor.subject, date: date.split(' · ')[0], time: date.split(' · ')[1] || '16:00 - 17:00', mode: 'Videollamada', status: 'Confirmada' as const }, ...bookings]; setBookings(next); persist(next); setSelected(null); showToast(`Tutoría con ${tutor.name} reservada`) }
  const cancelBooking = (id: number) => { const next = bookings.map(b => b.id === id ? { ...b, status: 'Cancelada' as const } : b); setBookings(next); persist(next); showToast('Tutoría cancelada correctamente') }
  const toggleFavorite = (id: number) => { const next = favorites.includes(id) ? favorites.filter(item => item !== id) : [...favorites, id]; setFavorites(next); persist(bookings, next); showToast(favorites.includes(id) ? 'Tutor eliminado de favoritos' : 'Tutor guardado en favoritos') }

  if (!signedIn) return <AuthScreen mode={authMode} setMode={setAuthMode} onSubmit={(name, email) => signIn(name, email, authMode === 'register')} />

  return <div className="app-shell">
    <aside className={`sidebar ${mobileMenu ? 'open' : ''}`}>
      <div className="brand"><div className="brand-mark"><GraduationCap size={22} /></div><span>tutor<span className="brand-accent">page</span></span></div>
      <div className="profile-mini"><div className="avatar avatar-small">{initials(account.name)}</div><div><strong>{account.name}</strong><span>{account.career}</span></div><button aria-label="Configuración"><Settings size={16} /></button></div>
      <nav aria-label="Navegación principal">
        <p className="nav-label">MENÚ PRINCIPAL</p>
        {[['Inicio', LayoutDashboard], ['Buscar tutores', Search], ['Mis tutorías', CalendarDays], ['Mi perfil', UserCircle2]].map(([label, Icon]) => <button key={label as string} className={`nav-item ${active === label ? 'active' : ''}`} onClick={() => { setActive(label as string); setMobileMenu(false) }}><Icon size={18} />{label as string}{label === 'Mis tutorías' && <span className="nav-count">{bookings.filter(b => b.status === 'Confirmada').length}</span>}</button>)}
      </nav>
      <div className="sidebar-bottom"><div className="help-card"><ShieldCheck size={19}/><div><strong>Aprende seguro</strong><span>Tutores verificados por tutorpage</span></div></div><button className="nav-item logout" onClick={() => { window.localStorage.removeItem('tutorpage-session'); setSignedIn(false); setAccount(emptyAccount('', '')); setBookings([]); setFavorites([]) }}><LogOut size={18}/>Cerrar sesión</button></div>
    </aside>
    <main className="main-content">
      <header className="topbar"><button className="mobile-menu" aria-label="Abrir menú" onClick={() => setMobileMenu(!mobileMenu)}><Menu size={22}/></button><div className="breadcrumb"><span>tutorpage</span><ChevronRight size={14}/><strong>{active}</strong></div><div className="top-actions"><button className="icon-button" aria-label="Notificaciones"><span className="notification-dot"/><Clock3 size={19}/></button><div className="avatar">JP</div></div></header>
      {active === 'Inicio' && <Dashboard account={account} setActive={setActive} setQuery={setQuery} setSubject={setSubject} bookings={bookings} favorites={favorites} cancelBooking={cancelBooking} />}
      {active === 'Buscar tutores' && <TutorDirectory filtered={filtered} query={query} setQuery={setQuery} subject={subject} setSubject={setSubject} onSelect={setSelected} />}
      {active === 'Mis tutorías' && <Bookings bookings={bookings} cancelBooking={cancelBooking} setActive={setActive} />}
      {active === 'Mi perfil' && <Profile account={account} />}
    </main>
    {selected && <TutorModal tutor={selected} onClose={() => setSelected(null)} onBook={() => bookTutor(selected)} />}
    {toast && <div className="toast"><CheckCircle2 size={18}/>{toast}</div>}
  </div>
}

function Dashboard({ account, setActive, setQuery, setSubject, bookings, favorites, cancelBooking }: { account: Account; setActive: (s: string) => void; setQuery: (s: string) => void; setSubject: (s: string) => void; bookings: Booking[]; favorites: number[]; cancelBooking: (id: number) => void }) {
  return <div className="page-wrap"><div className="welcome-row"><div><p className="eyebrow">MARTES, 08 DE OCTUBRE DE 2024</p><h1>Hola, {account.name.split(' ')[0] || 'estudiante'} <span className="wave">!</span></h1><p className="subheading">Encuentra el apoyo que necesitas para alcanzar tus metas.</p></div><button className="primary-button" onClick={() => setActive('Buscar tutores')}><Search size={17}/>Buscar un tutor</button></div>
    <section className="hero-card"><div><span className="hero-pill">TU PROGRESO IMPORTA</span><h2>Aprender es más fácil<br/><em>cuando no estás solo.</em></h2><p>Conecta con estudiantes expertos de tu universidad y avanza a tu ritmo.</p><button className="hero-button" onClick={() => setActive('Buscar tutores')}>Explorar tutores <ChevronRight size={16}/></button></div><div className="hero-illustration"><div className="float-card float-one"><BookOpen size={18}/><span>+20 materias</span></div><div className="person-shape"><GraduationCap size={82}/></div><div className="float-card float-two"><Star size={16} fill="currentColor"/><span>4.9 promedio</span></div></div></section>
    <div className="stats-grid"><Stat icon={<CalendarDays/>} label="Tutorías tomadas" value={String(bookings.filter(b => b.status === 'Confirmada').length)} change="Se actualiza al reservar"/><Stat icon={<Clock3/>} label="Horas de estudio" value={String((bookings.filter(b => b.status === 'Confirmada').length).toFixed(1))} change="Según tus tutorías"/><Stat icon={<Users/>} label="Tutores favoritos" value={String(favorites.length)} change="Tus tutores guardados"/></div>
    <div className="content-grid"><section className="panel upcoming"><div className="panel-heading"><div><p className="section-kicker">PRÓXIMAMENTE</p><h3>Tus próximas tutorías</h3></div><button className="text-button" onClick={() => setActive('Mis tutorías')}>Ver todas <ChevronRight size={15}/></button></div>{bookings.filter(b => b.status === 'Confirmada').slice(0,2).map(b => <div className="booking-row" key={b.id}><div className="date-box"><strong>{b.date.split(' ')[2]}</strong><span>OCT</span></div><div className="booking-info"><strong>{b.subject}</strong><span>{b.tutor} · {b.time}</span></div><span className="status">Confirmada</span><button className="cancel-link" onClick={() => cancelBooking(b.id)}>Cancelar</button></div>)}{bookings.filter(b => b.status === 'Confirmada').length === 0 && <Empty label="No tienes tutorías próximas." action="Buscar un tutor" onClick={() => setActive('Buscar tutores')}/>}</section>
      <section className="panel quick-search"><p className="section-kicker">¿QUÉ NECESITAS APRENDER?</p><h3>Encuentra tu próximo tutor</h3><p>Busca por materia, carrera o tema.</p><div className="search-input"><Search size={17}/><input placeholder="Ej. Cálculo, Python..." onChange={e => { setQuery(e.target.value); setActive('Buscar tutores') }} /><ChevronRight size={17}/></div><div className="chips">{['Cálculo','Programación','Inglés'].map(s => <button key={s} onClick={() => { setSubject(s); setActive('Buscar tutores') }}>{s}</button>)}</div></section></div>
  </div>
}
function Stat({ icon, label, value, change }: { icon: React.ReactNode; label: string; value: string; change: string }) { return <div className="stat-card"><div className="stat-icon">{icon}</div><div><span>{label}</span><strong>{value}</strong><small>{change}</small></div></div> }
function Empty({ label, action, onClick }: { label: string; action: string; onClick: () => void }) { return <div className="empty"><p>{label}</p><button className="text-button" onClick={onClick}>{action}</button></div> }

function TutorDirectory({ filtered, query, setQuery, subject, setSubject, onSelect }: { filtered: Tutor[]; query: string; setQuery: (s: string) => void; subject: string; setSubject: (s: string) => void; onSelect: (t: Tutor) => void }) { return <div className="page-wrap"><div className="directory-heading"><div><p className="eyebrow">20 TUTORES DISPONIBLES</p><h1>Encuentra tu tutor ideal</h1><p className="subheading">Personas expertas listas para ayudarte a conseguir tus objetivos.</p></div></div><div className="filters"><div className="large-search"><Search size={19}/><input value={query} onChange={e => setQuery(e.target.value)} placeholder="Buscar por nombre, materia o carrera..."/></div><select value={subject} onChange={e => setSubject(e.target.value)} aria-label="Filtrar por materia"><option>Todas</option>{Array.from(new Set(tutors.map(t => t.subject))).map(s => <option key={s}>{s}</option>)}</select></div><div className="result-line"><span>{filtered.length} tutores encontrados</span><span className="verified"><CheckCircle2 size={15}/> Perfiles verificados</span></div><div className="tutor-grid">{filtered.map(t => <TutorCard key={t.id} tutor={t} onSelect={onSelect}/>)}</div>{filtered.length === 0 && <Empty label="No encontramos tutores con esa búsqueda." action="Limpiar filtros" onClick={() => { setQuery(''); setSubject('Todas') }}/>}</div> }
function TutorCard({ tutor, onSelect }: { tutor: Tutor; onSelect: (t: Tutor) => void }) { return <article className="tutor-card"><div className="tutor-top"><div className="avatar tutor-avatar" style={{ background: tutor.color }}>{tutor.initials}</div><div className="rating"><Star size={14} fill="currentColor"/>{tutor.rating}</div></div><h3>{tutor.name}</h3><p className="tutor-subject">{tutor.subject}</p><p className="tutor-career"><GraduationCap size={14}/>{tutor.career}</p><div className="expertise"><span>Experto en</span>{tutor.expertise}</div><div className="tutor-footer"><span><Users size={14}/>{tutor.sessions} sesiones</span><button className="small-button" onClick={() => onSelect(tutor)}>Ver perfil</button></div></article> }
function TutorModal({ tutor, onClose, onBook }: { tutor: Tutor; onClose: () => void; onBook: () => void }) { return <div className="modal-backdrop" onClick={onClose}><div className="modal" onClick={e => e.stopPropagation()}><button className="close-button" onClick={onClose} aria-label="Cerrar"><X size={19}/></button><div className="modal-profile"><div className="avatar tutor-avatar large" style={{ background: tutor.color }}>{tutor.initials}</div><div><h2>{tutor.name}</h2><p>{tutor.subject} · {tutor.career}</p><span className="rating"><Star size={14} fill="currentColor"/>{tutor.rating} · {tutor.sessions} sesiones</span></div></div><div className="modal-section"><span>ESPECIALIDAD</span><p>{tutor.expertise}</p></div><div className="modal-section"><span>PRÓXIMA DISPONIBILIDAD</span><div className="availability"><CalendarDays size={17}/><strong>{tutor.availability}</strong><small>Sesión de 60 minutos · Videollamada</small></div></div><button className="primary-button full" onClick={onBook}>Reservar tutoría <ChevronRight size={16}/></button></div></div> }
function Bookings({ bookings, cancelBooking, setActive }: { bookings: Booking[]; cancelBooking: (id: number) => void; setActive: (s: string) => void }) { return <div className="page-wrap"><div className="directory-heading"><p className="eyebrow">TU AGENDA</p><h1>Mis tutorías</h1><p className="subheading">Consulta y gestiona todas tus sesiones de aprendizaje.</p></div><section className="panel bookings-panel">{bookings.map(b => <div className={`full-booking ${b.status === 'Cancelada' ? 'cancelled' : ''}`} key={b.id}><div className="date-box"><strong>{b.date.split(' ')[2]}</strong><span>OCT</span></div><div className="booking-info"><strong>{b.subject}</strong><span>Con {b.tutor}</span><small><CalendarDays size={13}/>{b.date} · {b.time} · {b.mode}</small></div><span className={`status ${b.status === 'Cancelada' ? 'status-cancelled' : ''}`}>{b.status}</span>{b.status === 'Confirmada' && <button className="cancel-link" onClick={() => cancelBooking(b.id)}>Cancelar</button>}</div>)}<button className="primary-button" onClick={() => setActive('Buscar tutores')}><Search size={17}/> Reservar nueva tutoría</button></section></div> }
function Profile({ account }: { account: Account }) { return <div className="page-wrap"><div className="directory-heading"><p className="eyebrow">MI CUENTA</p><h1>Mi perfil</h1><p className="subheading">Administra tu información y preferencias.</p></div><section className="panel profile-panel"><div className="profile-hero"><div className="avatar profile-avatar">{initials(account.name)}</div><div><h2>{account.name}</h2><p>{account.email}</p><span className="member-pill">Estudiante desde {account.createdAt}</span></div><button className="secondary-button">Editar perfil</button></div><div className="profile-fields"><label>Nombre completo<input value={account.name} readOnly /></label><label>Correo electrónico<input value={account.email} readOnly /></label><label>Carrera<input value={account.career} readOnly /></label><label>Universidad<input value={account.university} readOnly /></label></div></section></div> }
function AuthScreen({ mode, setMode, onSubmit }: { mode: 'login' | 'register'; setMode: (m: 'login' | 'register') => void; onSubmit: (name: string, email: string) => void }) {
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  return <main className="auth-page"><div className="auth-decoration"><div className="auth-brand"><div className="brand-mark"><GraduationCap size={22}/></div>tutor<span>page</span></div><div className="auth-quote"><h1>Tu próximo logro<br/><em>empieza aquí.</em></h1><p>Conecta con tutores que entienden tu camino.</p></div></div><div className="auth-form-wrap"><div className="auth-form"><div className="auth-mobile-brand"><div className="brand-mark"><GraduationCap size={20}/></div>tutor<span>page</span></div><p className="eyebrow">BIENVENIDO A TUTORPAGE</p><h2>{mode === 'login' ? 'Inicia sesión' : 'Crea tu cuenta'}</h2><p className="auth-sub">{mode === 'login' ? 'Continúa tu camino de aprendizaje.' : 'Empieza a aprender de forma diferente.'}</p>{mode === 'register' && <label>Nombre completo<input value={name} onChange={e => setName(e.target.value)} placeholder="Tu nombre" /></label>}<label>Correo electrónico<input value={email} onChange={e => setEmail(e.target.value)} type="email" placeholder="nombre@universidad.edu" /></label><label>Contraseña<input type="password" placeholder="••••••••" /></label><button className="primary-button full" onClick={() => onSubmit(name, email)}>{mode === 'login' ? 'Iniciar sesión' : 'Crear cuenta'} <ChevronRight size={16}/></button><p className="auth-switch">{mode === 'login' ? '¿Aún no tienes cuenta?' : '¿Ya tienes una cuenta?'} <button onClick={() => setMode(mode === 'login' ? 'register' : 'login')}>{mode === 'login' ? 'Regístrate' : 'Inicia sesión'}</button></p></div></div></main>
}
